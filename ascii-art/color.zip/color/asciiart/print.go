package asciiart

import (
	"strings"
)

func PrintAsciiArt(userText, alignement string, asciiTable [][]string, terminalWidth int, colorMap map[string][]string) string {
	var AsciiArt string
	for _, userLine := range strings.Split(userText, `\n`) {
		if userLine == "" {
			AsciiArt += "\n"
			continue
		}
		lenAscii := GetAsciiLineLen(userLine, asciiTable)
		AsciiArt += PrintAsciiLine(userLine, alignement, asciiTable, lenAscii, terminalWidth, colorMap)
	}
	return AsciiArt
}

func PrintAsciiLine(userLine, alignement string, asciiTable [][]string, lenAscii, terminalWidth int, colorMap map[string][]string) string {
	var output string
	var justify bool
	for i := 0; i < fontLines; i++ {
		switch alignement {
		case "left":
			output += ""
		case "center":
			output += strings.Repeat(" ", (terminalWidth-lenAscii)/2)
		case "right":
			output += strings.Repeat(" ", terminalWidth-lenAscii)
		case "justify":
			justify = true
			userLine = strings.Join(strings.Fields(userLine), " ")
		}
		for j, char := range userLine {
			if char == ' ' && justify {
				output += GetJustifySpace(terminalWidth, userLine, asciiTable)
				continue
			}
			if color, paint := IsColorIndex(GetColoringIndices(colorMap, userLine), j); paint && asciiColor == "" {
				output += color + asciiTable[int(char-32)][i] + reset
				continue
			}
			output += asciiColor + asciiTable[int(char-32)][i]

		}
		output += "\n"

	}
	return output
}
